package com.example.trollkeyboard

import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.inputmethodservice.InputMethodService
import android.os.Handler
import android.os.Looper
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

class TrollKeyboardService : InputMethodService() {

    private val ruRows = listOf("йцукенгшщзхъ", "фывапролджэ", "ячсмитьбю")
    private val enRows = listOf("qwertyuiop", "asdfghjkl", "zxcvbnm")

    private var ru = true
    private var shift = false
    private lateinit var chips: List<TextView>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    // ---------- UI ----------

    private fun key(label: String, weight: Float = 1f, onClick: () -> Unit) = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 20f
        setTextColor(Color.WHITE)
        background = GradientDrawable().apply {
            setColor(0xFF3C4043.toInt()); cornerRadius = dp(6).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(0, dp(48), weight).apply {
            setMargins(dp(2), dp(3), dp(2), dp(3))
        }
        setOnClickListener { onClick() }
    }

    private fun chip() = TextView(this).apply {
        gravity = Gravity.CENTER
        textSize = 14f
        maxLines = 1
        ellipsize = TextUtils.TruncateAt.END
        setTextColor(Color.WHITE)
        setPadding(dp(6), 0, dp(6), 0)
        background = GradientDrawable().apply {
            setColor(0xFF5F3DC4.toInt()); cornerRadius = dp(16).toFloat()
        }
        layoutParams = LinearLayout.LayoutParams(0, dp(36), 1f).apply {
            setMargins(dp(3), dp(4), dp(3), dp(4))
        }
        visibility = View.INVISIBLE
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        views.forEach { addView(it) }
    }

    override fun onCreateInputView(): View {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF202124.toInt())
            setPadding(dp(2), dp(2), dp(2), dp(6))
        }
        chips = List(3) { chip() }
        root.addView(row(*chips.toTypedArray()))

        (if (ru) ruRows else enRows).forEach { letters ->
            root.addView(row(*letters.map { ch ->
                key(if (shift) ch.uppercase() else ch.toString()) { type(ch.toString()) }
            }.toTypedArray()))
        }

        root.addView(row(
            key(if (shift) "⬆" else "⇧") { shift = !shift; refresh() },
            key(if (ru) "RU" else "EN") { ru = !ru; refresh() },
            key(if (ru) "пробел" else "space", 4f) { commit(" ") },
            key("⌫") { currentInputConnection?.deleteSurroundingText(1, 0) },
            key("⏎") { sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER) }
        ))
        return root
    }

    private fun refresh() = setInputView(onCreateInputView())

    // ---------- ввод ----------

    private fun commit(s: String) {
        currentInputConnection?.commitText(s, 1)
    }

    private fun type(ch: String) {
        commit(if (shift) ch.uppercase() else ch)
        if (shift) { shift = false; refresh() }
    }

    // ---------- тролинг-подсказки ----------

    private fun isPasswordField(): Boolean {
        val t = currentInputEditorInfo?.inputType ?: return false
        val variation = t and InputType.TYPE_MASK_VARIATION
        return (t and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_TEXT &&
            (variation == InputType.TYPE_TEXT_VARIATION_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD ||
                variation == InputType.TYPE_TEXT_VARIATION_WEB_PASSWORD) ||
            (t and InputType.TYPE_MASK_CLASS) == InputType.TYPE_CLASS_NUMBER &&
            variation == InputType.TYPE_NUMBER_VARIATION_PASSWORD
    }

    override fun onUpdateSelection(
        oldSelStart: Int, oldSelEnd: Int, newSelStart: Int, newSelEnd: Int,
        candidatesStart: Int, candidatesEnd: Int
    ) {
        super.onUpdateSelection(oldSelStart, oldSelEnd, newSelStart, newSelEnd, candidatesStart, candidatesEnd)
        updateSuggestions()
    }

    override fun onStartInputView(info: android.view.inputmethod.EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        updateSuggestions()
    }

    private fun updateSuggestions() {
        if (!::chips.isInitialized) return
        chips.forEach { it.visibility = View.INVISIBLE }
        if (isPasswordField()) return

        val before = currentInputConnection?.getTextBeforeCursor(200, 0)?.toString().orEmpty()
        val raw = before.takeLastWhile { it !in ".!?\n" }   // текущее предложение
        val text = raw.trim()
        if (text.length < 3) return

        val options = TrollEngine.offline(text).toMutableList()
        val useAi = TrollEngine.GEMINI_KEY.isNotBlank()
        if (useAi) options[2] = "🤖 ИИ-подколка"

        chips.forEachIndexed { i, chip ->
            chip.text = options[i]
            chip.visibility = View.VISIBLE
            chip.setOnClickListener {
                if (useAi && i == 2) {
                    Thread {
                        val r = TrollEngine.ai(text)
                        if (r != null) Handler(Looper.getMainLooper()).post { apply(raw, r) }
                    }.start()
                } else apply(raw, options[i])
            }
        }
    }

    /** Заменяет набранное предложение на тролинг-вариант */
    private fun apply(raw: String, troll: String) {
        val ic = currentInputConnection ?: return
        ic.beginBatchEdit()
        ic.deleteSurroundingText(raw.length, 0)
        ic.commitText(troll, 1)
        ic.endBatchEdit()
    }
}
