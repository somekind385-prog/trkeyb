package com.example.trollkeyboard

import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object TrollEngine {
    // Для личных тестов можно вставить ключ Gemini. Для публикации — только через свой сервер-прокси.
    const val GEMINI_KEY = ""
    private const val MODEL = "gemini-2.5-flash" // проверьте актуальное имя модели в документации

    private val roasts = listOf(
        "Ну ты и гений 🧠",
        "Это ты сам придумал? Серьёзно? 😂",
        "Записал в блокнотик, потом посмеюсь 📓",
        "Мощно. Даже не ожидал 🤡",
        "Окей, бумер 👴",
        "Ладно-ладно, не плачь 😭"
    )

    /** пОдРаЗнИвАнИе: чередуем регистр букв */
    fun mock(s: String): String {
        var up = false
        return buildString {
            for (c in s) {
                if (c.isLetter()) {
                    append(if (up) c.uppercaseChar() else c.lowercaseChar())
                    up = !up
                } else append(c)
            }
        }
    }

    /** Офлайн-варианты: работают без интернета */
    fun offline(text: String): List<String> = listOf(
        mock(text) + " 🤡",
        "О да, «$text» — просто гениально 🙄",
        "$text? ${roasts.random()}"
    )

    /** ИИ-подколка. Блокирующий вызов — запускать только в фоновом потоке. */
    fun ai(text: String): String? {
        if (GEMINI_KEY.isBlank()) return null
        return try {
            val prompt = "Перепиши сообщение как короткую дружескую подколку (1 предложение, " +
                "без мата и оскорблений по признакам). Верни только текст: $text"
            val body = JSONObject().put(
                "contents", JSONArray().put(
                    JSONObject().put(
                        "parts", JSONArray().put(JSONObject().put("text", prompt))
                    )
                )
            )
            val url = URL("https://generativelanguage.googleapis.com/v1beta/models/$MODEL:generateContent?key=$GEMINI_KEY")
            val conn = (url.openConnection() as HttpURLConnection).apply {
                requestMethod = "POST"
                setRequestProperty("Content-Type", "application/json")
                doOutput = true
                connectTimeout = 8000
                readTimeout = 8000
            }
            conn.outputStream.use { it.write(body.toString().toByteArray()) }
            val resp = conn.inputStream.bufferedReader().readText()
            JSONObject(resp).getJSONArray("candidates").getJSONObject(0)
                .getJSONObject("content").getJSONArray("parts").getJSONObject(0)
                .getString("text").trim()
        } catch (e: Exception) {
            null
        }
    }
}
